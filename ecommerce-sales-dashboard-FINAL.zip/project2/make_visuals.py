import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

sns.set_theme(style="whitegrid", palette="viridis")
plt.rcParams["figure.dpi"] = 120

# --- 1. Revenue by category ---
df = pd.read_csv("data/kpi_1_revenue_by_category.csv")
plt.figure(figsize=(8, 5))
sns.barplot(data=df, x="total_revenue", y="category", palette="crest")
plt.title("Revenue by Product Category", fontsize=13, fontweight="bold")
plt.xlabel("Revenue (₹)")
plt.ylabel("")
plt.tight_layout()
plt.savefig("visuals/01_revenue_by_category.png")
plt.close()

# --- 2. Monthly revenue trend + Q4 spike ---
df = pd.read_csv("data/kpi_2_monthly_revenue_growth.csv")
plt.figure(figsize=(9, 5))
colors = ["#4C72B0"] * 9 + ["#DD8452"] * 3  # highlight Q4
plt.bar(df["order_month"], df["monthly_revenue"], color=colors)
plt.title("Monthly Revenue Trend — Q4 Spike Highlighted", fontsize=13, fontweight="bold")
plt.xlabel("Month")
plt.ylabel("Revenue (₹)")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig("visuals/02_monthly_revenue_trend.png")
plt.close()

# --- 3. Top 10 products ---
df = pd.read_csv("data/kpi_4_top10_products.csv")
plt.figure(figsize=(8, 5))
sns.barplot(data=df, x="total_revenue", y="product_name", palette="mako")
plt.title("Top 10 Performing Products", fontsize=13, fontweight="bold")
plt.xlabel("Revenue (₹)")
plt.ylabel("")
plt.tight_layout()
plt.savefig("visuals/03_top10_products.png")
plt.close()

# --- 4. Return rate by category ---
df = pd.read_csv("data/kpi_6_return_rate_by_category.csv")
plt.figure(figsize=(8, 5))
sns.barplot(data=df, x="return_rate_pct", y="category", palette="flare")
plt.title("Return Rate by Category (%)", fontsize=13, fontweight="bold")
plt.xlabel("Return Rate (%)")
plt.ylabel("")
plt.tight_layout()
plt.savefig("visuals/04_return_rate_by_category.png")
plt.close()

# --- 5. Return reasons ---
df = pd.read_csv("data/kpi_7_top_return_reasons.csv")
plt.figure(figsize=(7, 7))
plt.pie(df["return_count"], labels=df["reason"], autopct="%1.1f%%",
        colors=sns.color_palette("Set2"), startangle=90)
plt.title("Return Reasons Breakdown", fontsize=13, fontweight="bold")
plt.tight_layout()
plt.savefig("visuals/05_return_reasons.png")
plt.close()

# --- 6. Region-wise performance ---
df = pd.read_csv("data/kpi_8_region_performance.csv")
fig, ax1 = plt.subplots(figsize=(8, 5))
sns.barplot(data=df, x="region", y="revenue", ax=ax1, palette="crest")
ax1.set_ylabel("Revenue (₹)")
ax1.set_title("Region-wise Revenue & Average Order Value", fontsize=13, fontweight="bold")
ax2 = ax1.twinx()
ax2.plot(df["region"], df["avg_order_value"], color="red", marker="o", linewidth=2)
ax2.set_ylabel("Avg Order Value (₹)", color="red")
plt.tight_layout()
plt.savefig("visuals/06_region_performance.png")
plt.close()

# --- 7. Customer segment revenue ---
df = pd.read_csv("data/kpi_5_segment_revenue.csv")
plt.figure(figsize=(7, 5))
sns.barplot(data=df, x="customer_segment", y="revenue", palette="viridis")
plt.title("Revenue by Customer Segment", fontsize=13, fontweight="bold")
plt.xlabel("")
plt.ylabel("Revenue (₹)")
plt.tight_layout()
plt.savefig("visuals/07_segment_revenue.png")
plt.close()

# --- 8. Payment method share ---
df = pd.read_csv("data/kpi_10_payment_method_share.csv")
plt.figure(figsize=(7, 7))
plt.pie(df["orders"], labels=df["payment_method"], autopct="%1.1f%%",
        colors=sns.color_palette("pastel"), startangle=90)
plt.title("Payment Method Preference", fontsize=13, fontweight="bold")
plt.tight_layout()
plt.savefig("visuals/08_payment_method_share.png")
plt.close()

print("All 8 charts saved to visuals/")
