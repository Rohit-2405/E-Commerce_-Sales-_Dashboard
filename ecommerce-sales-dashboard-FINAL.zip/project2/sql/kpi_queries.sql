/* ============================================================
   E-COMMERCE SALES PERFORMANCE DASHBOARD — SQL KPI QUERIES
   Database: SQLite (ecommerce.db)
   Tables  : orders, customers, products, returns
   ============================================================ */

/* 1. REVENUE BY CATEGORY */
SELECT
    category,
    ROUND(SUM(net_amount), 2) AS total_revenue,
    COUNT(DISTINCT order_id) AS total_orders,
    ROUND(SUM(net_amount) * 100.0 / (SELECT SUM(net_amount) FROM orders WHERE order_status = 'Delivered'), 2) AS pct_of_total_revenue
FROM orders
WHERE order_status = 'Delivered'
GROUP BY category
ORDER BY total_revenue DESC;


/* 2. MONTHLY REVENUE + MoM GROWTH RATE (using window function) */
WITH monthly AS (
    SELECT
        strftime('%Y-%m', order_date) AS order_month,
        ROUND(SUM(net_amount), 2) AS monthly_revenue
    FROM orders
    WHERE order_status = 'Delivered'
    GROUP BY order_month
)
SELECT
    order_month,
    monthly_revenue,
    ROUND(
        (monthly_revenue - LAG(monthly_revenue) OVER (ORDER BY order_month))
        * 100.0 / LAG(monthly_revenue) OVER (ORDER BY order_month), 2
    ) AS mom_growth_pct
FROM monthly
ORDER BY order_month;


/* 3. Q4 vs Q1-Q3 REVENUE SPIKE */
SELECT
    CASE WHEN CAST(strftime('%m', order_date) AS INTEGER) IN (10,11,12)
         THEN 'Q4' ELSE 'Q1-Q3' END AS period,
    ROUND(SUM(net_amount), 2) AS revenue,
    ROUND(SUM(net_amount) * 1.0 / COUNT(DISTINCT strftime('%m', order_date)), 2) AS avg_monthly_revenue
FROM orders
WHERE order_status = 'Delivered'
GROUP BY period;


/* 4. TOP 10 PERFORMING PRODUCTS */
SELECT
    p.product_name,
    p.category,
    SUM(o.quantity) AS units_sold,
    ROUND(SUM(o.net_amount), 2) AS total_revenue
FROM orders o
JOIN products p ON o.product_id = p.product_id
WHERE o.order_status = 'Delivered'
GROUP BY p.product_id
ORDER BY total_revenue DESC
LIMIT 10;


/* 5. CUSTOMER SEGMENT-WISE REVENUE */
SELECT
    c.customer_segment,
    COUNT(DISTINCT o.customer_id) AS customers,
    ROUND(SUM(o.net_amount), 2) AS revenue,
    ROUND(SUM(o.net_amount) * 1.0 / COUNT(DISTINCT o.customer_id), 2) AS avg_revenue_per_customer
FROM orders o
JOIN customers c ON o.customer_id = c.customer_id
WHERE o.order_status = 'Delivered'
GROUP BY c.customer_segment
ORDER BY revenue DESC;


/* 6. RETURN RATE BY CATEGORY */
SELECT
    o.category,
    COUNT(DISTINCT o.order_id) AS total_orders,
    COUNT(DISTINCT r.order_id) AS returned_orders,
    ROUND(COUNT(DISTINCT r.order_id) * 100.0 / COUNT(DISTINCT o.order_id), 2) AS return_rate_pct
FROM orders o
LEFT JOIN returns r ON o.order_id = r.order_id
GROUP BY o.category
ORDER BY return_rate_pct DESC;


/* 7. TOP RETURN REASONS */
SELECT
    reason,
    COUNT(*) AS return_count,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM returns), 2) AS pct_of_returns
FROM returns
GROUP BY reason
ORDER BY return_count DESC;


/* 8. REGION-WISE PERFORMANCE */
SELECT
    region,
    ROUND(SUM(net_amount), 2) AS revenue,
    COUNT(DISTINCT order_id) AS orders,
    ROUND(SUM(net_amount) / COUNT(DISTINCT order_id), 2) AS avg_order_value
FROM orders
WHERE order_status = 'Delivered'
GROUP BY region
ORDER BY revenue DESC;


/* 9. CUSTOMER CHURN PROXY — customers with no order in the last 90 days
      (relative to the most recent order date in the dataset)          */
WITH last_order AS (
    SELECT customer_id, MAX(order_date) AS last_purchase
    FROM orders
    GROUP BY customer_id
),
max_date AS (
    SELECT MAX(order_date) AS ref_date FROM orders
)
SELECT
    COUNT(*) AS total_customers,
    SUM(CASE WHEN julianday((SELECT ref_date FROM max_date)) - julianday(last_purchase) > 60
             THEN 1 ELSE 0 END) AS churned_customers,
    ROUND(SUM(CASE WHEN julianday((SELECT ref_date FROM max_date)) - julianday(last_purchase) > 60
             THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS churn_rate_pct
FROM last_order;


/* 10. PAYMENT METHOD PREFERENCE */
SELECT
    payment_method,
    COUNT(*) AS orders,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM orders WHERE order_status='Delivered'), 2) AS pct_share
FROM orders
WHERE order_status = 'Delivered'
GROUP BY payment_method
ORDER BY orders DESC;
