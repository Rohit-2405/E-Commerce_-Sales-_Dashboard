# 🛒 E-Commerce Sales Performance Dashboard

A data analytics portfolio project analyzing **50,000+ e-commerce transactions** to uncover revenue
trends, top-performing products, customer segments, and return/churn patterns — with actionable
business recommendations.

**Tools:** Python (Pandas, NumPy) · SQL (SQLite) · Matplotlib/Seaborn · Power BI

---

## 📌 Project Overview

This project simulates a real-world Data Analyst workflow: taking messy raw transactional data,
cleaning it, extracting KPIs with SQL, visualizing trends, and translating findings into business
recommendations — the exact skill set expected in entry-level Data Analyst roles.

**Dataset:** 12 months (2024) of synthetic e-commerce transactions across 6 product categories,
2,500 customers, and 4 regions — modeled on real Indian e-commerce transaction patterns
(`data/orders.csv`, `customers.csv`, `products.csv`, `returns.csv`).

## 🎯 Key Questions Answered
- Which product categories and products drive the most revenue?
- How does revenue trend month-over-month, and what causes the Q4 spike?
- Which categories have the highest return rates, and why?
- How does revenue break down by customer segment and region?
- What does customer churn look like, and what can reduce it?

## 🛠️ Methodology

1. **Data Cleaning (Pandas)** — handled duplicate orders, missing revenue values, and invalid
   quantity entries.
2. **SQL KPI Extraction (SQLite)** — 10 queries using JOINs, window functions (`LAG`), and CTEs
   to compute revenue by category, MoM growth rate, top-10 products, return rates, churn rate,
   and more. Full queries in [`sql/kpi_queries.sql`](sql/kpi_queries.sql).
3. **Visualization** — 8 charts built with Matplotlib/Seaborn covering revenue trends, product
   performance, returns, and customer segments (see [`visuals/`](visuals/)).
4. **Power BI Dashboard** — the same KPIs were rebuilt as an interactive dashboard with dropdown
   slicers for category and month. Open [`powerbi/ecommerce_dashboard.pbix`](powerbi/ecommerce_dashboard.pbix)
   in Power BI Desktop to explore it live, or see the screenshot below.

![Power BI Dashboard](powerbi/dashboard_screenshot.png)

## 📊 Key Findings

| Metric | Finding |
|---|---|
| **Revenue spike** | Q4 (Oct–Dec) average monthly revenue is ~60-70% higher than Q1-Q3 average |
| **Top category** | Electronics — ~33% of total revenue |
| **Highest return rate** | Books & Stationery, driven by "Not as Described" / "Wrong Item Sent" |
| **Best customer segment** | "Loyal" customers have the highest average revenue per customer |
| **Payment preference** | Fairly even split across UPI, Cards, Net Banking, and COD |

## 💡 Business Recommendations
1. **Fix product-description accuracy** for high-return categories — the top return reasons are
   logistics/listing issues, not demand issues, so they're fixable without price cuts.
2. **Launch a "New → Regular" conversion campaign** — a second-purchase incentive within 30 days
   of signup, since New customers under-index on repeat purchases.
3. **Pre-scale inventory & delivery capacity ahead of Q4** — given the consistent October revenue
   jump, procurement should start planning by August/September.

## 📁 Repository Structure
```
├── data/                     # Raw & cleaned CSV datasets + KPI query outputs
├── sql/kpi_queries.sql       # All 10 SQL KPI queries
├── notebooks/                # Full Jupyter notebook (EDA + SQL + charts + insights)
├── visuals/                  # Exported chart images
├── powerbi/                  # Power BI dashboard (.pbix) + screenshot
├── generate_data.py          # Synthetic dataset generator
├── run_sql_analysis.py       # Runs cleaning + all SQL KPIs
├── make_visuals.py           # Generates all charts
└── README.md
```

## 🚀 How to Run
```bash
pip install pandas numpy matplotlib seaborn faker
python generate_data.py        # generates the dataset
python run_sql_analysis.py     # cleans data + runs SQL KPIs
python make_visuals.py         # generates charts
# or open notebooks/ecommerce_sales_analysis.ipynb for the full walkthrough
```

## 📈 Sample Visualization

![Monthly Revenue Trend](visuals/02_monthly_revenue_trend.png)

---
*Note: Dataset is synthetically generated for portfolio purposes, modeled on real-world
e-commerce transaction patterns.*
