"""
Generates a realistic synthetic e-commerce dataset:
- orders.csv      : order-level transactions
- customers.csv   : customer master data
- products.csv     : product catalog
- returns.csv       : return records

Designed to mimic real Kaggle e-commerce datasets so it can be used
for a Data Analyst portfolio project (EDA + SQL KPIs + Power BI dashboard).
"""

import pandas as pd
import numpy as np
from faker import Faker
import random
from datetime import datetime, timedelta

fake = Faker()
Faker.seed(42)
random.seed(42)
np.random.seed(42)

# ---------------------------------------------------------
# 1. PRODUCTS
# ---------------------------------------------------------
categories = {
    "Electronics": ["Wireless Earbuds", "Bluetooth Speaker", "Smartwatch", "Power Bank",
                     "Laptop Stand", "USB-C Hub", "Webcam", "Mechanical Keyboard"],
    "Fashion": ["Men's T-Shirt", "Women's Kurti", "Denim Jacket", "Running Shoes",
                "Leather Wallet", "Sunglasses", "Backpack", "Formal Shirt"],
    "Home & Kitchen": ["Non-Stick Pan", "Air Fryer", "LED Table Lamp", "Storage Boxes",
                        "Mixer Grinder", "Bedsheet Set", "Water Bottle", "Wall Clock"],
    "Beauty & Personal Care": ["Face Wash", "Hair Dryer", "Perfume", "Trimmer",
                                "Moisturizer", "Lipstick Set", "Sunscreen", "Shampoo"],
    "Sports & Fitness": ["Yoga Mat", "Dumbbell Set", "Resistance Bands", "Cricket Bat",
                          "Football", "Skipping Rope", "Gym Bag", "Water Bottle Sipper"],
    "Books & Stationery": ["Notebook Pack", "Fiction Novel", "Sketch Pens", "Desk Organizer",
                            "Planner Diary", "Highlighters", "Backpack Pencil Case", "Whiteboard"],
}

products = []
pid = 1000
for cat, items in categories.items():
    for item in items:
        base_price = {
            "Electronics": (800, 6000),
            "Fashion": (300, 2500),
            "Home & Kitchen": (400, 4000),
            "Beauty & Personal Care": (150, 1800),
            "Sports & Fitness": (250, 3000),
            "Books & Stationery": (80, 900),
        }[cat]
        products.append({
            "product_id": f"P{pid}",
            "product_name": item,
            "category": cat,
            "unit_price": round(random.uniform(*base_price), 2)
        })
        pid += 1

products_df = pd.DataFrame(products)

# ---------------------------------------------------------
# 2. CUSTOMERS
# ---------------------------------------------------------
n_customers = 2500
indian_cities = ["Hyderabad", "Bengaluru", "Mumbai", "Delhi", "Pune", "Chennai",
                  "Kolkata", "Ahmedabad", "Jaipur", "Lucknow", "Chandigarh", "Kochi"]

customers = []
for i in range(1, n_customers + 1):
    signup_date = fake.date_between(start_date="-2y", end_date="-30d")
    customers.append({
        "customer_id": f"C{10000+i}",
        "customer_name": fake.name(),
        "city": random.choice(indian_cities),
        "signup_date": signup_date,
        "customer_segment": random.choices(
            ["New", "Regular", "Loyal", "VIP"], weights=[0.35, 0.35, 0.2, 0.1]
        )[0]
    })
customers_df = pd.DataFrame(customers)

# ---------------------------------------------------------
# 3. ORDERS  (12 months of data, with a deliberate Q4 spike)
# ---------------------------------------------------------
start_date = datetime(2024, 1, 1)
end_date = datetime(2024, 12, 31)
n_orders = 50000

# monthly weight -> creates a natural Q4 (Oct-Dec) festive-season spike
monthly_weights = {1: 0.7, 2: 0.7, 3: 0.75, 4: 0.8, 5: 0.85, 6: 0.85,
                    7: 0.9, 8: 0.9, 9: 1.0, 10: 1.35, 11: 1.5, 12: 1.4}

months = list(monthly_weights.keys())
weights = list(monthly_weights.values())
weights = [w / sum(weights) for w in weights]

orders = []
regions_map = {
    "Hyderabad": "South", "Bengaluru": "South", "Chennai": "South", "Kochi": "South",
    "Mumbai": "West", "Pune": "West", "Ahmedabad": "West",
    "Delhi": "North", "Jaipur": "North", "Lucknow": "North", "Chandigarh": "North",
    "Kolkata": "East"
}

payment_methods = ["UPI", "Credit Card", "Debit Card", "Net Banking", "Cash on Delivery"]
order_status_weights = ["Delivered"] * 88 + ["Cancelled"] * 6 + ["Returned"] * 6

for i in range(1, n_orders + 1):
    month = random.choices(months, weights=weights)[0]
    day = random.randint(1, 28)
    order_date = datetime(2024, month, day) + timedelta(hours=random.randint(0, 23))

    cust = customers_df.sample(1).iloc[0]
    prod = products_df.sample(1).iloc[0]
    qty = random.choices([1, 2, 3, 4], weights=[0.6, 0.25, 0.1, 0.05])[0]

    # small random discount
    discount_pct = random.choices([0, 5, 10, 15, 20], weights=[0.4, 0.2, 0.2, 0.1, 0.1])[0]
    gross_amount = round(prod["unit_price"] * qty, 2)
    discount_amount = round(gross_amount * discount_pct / 100, 2)
    net_amount = round(gross_amount - discount_amount, 2)

    status = random.choice(order_status_weights)

    orders.append({
        "order_id": f"ORD{100000+i}",
        "order_date": order_date.strftime("%Y-%m-%d"),
        "customer_id": cust["customer_id"],
        "product_id": prod["product_id"],
        "category": prod["category"],
        "region": regions_map[cust["city"]],
        "city": cust["city"],
        "quantity": qty,
        "unit_price": prod["unit_price"],
        "discount_pct": discount_pct,
        "gross_amount": gross_amount,
        "net_amount": net_amount,
        "payment_method": random.choice(payment_methods),
        "order_status": status
    })

orders_df = pd.DataFrame(orders)

# ---------------------------------------------------------
# 4. RETURNS  (subset of "Returned" orders, with reasons)
# ---------------------------------------------------------
return_reasons = ["Defective Product", "Size/Fit Issue", "Not as Described",
                   "Changed Mind", "Late Delivery", "Wrong Item Sent"]

returned_orders = orders_df[orders_df["order_status"] == "Returned"].copy()
returns = []
for _, row in returned_orders.iterrows():
    order_dt = datetime.strptime(row["order_date"], "%Y-%m-%d")
    return_dt = order_dt + timedelta(days=random.randint(1, 14))
    returns.append({
        "return_id": f"RET{row['order_id'][3:]}",
        "order_id": row["order_id"],
        "return_date": return_dt.strftime("%Y-%m-%d"),
        "reason": random.choice(return_reasons),
        "refund_amount": row["net_amount"]
    })
returns_df = pd.DataFrame(returns)

# ---------------------------------------------------------
# 5. Inject a few realistic "dirty data" issues (for the
#    Pandas cleaning step recruiters expect to see)
# ---------------------------------------------------------
dirty_idx = orders_df.sample(frac=0.02, random_state=1).index
orders_df.loc[dirty_idx[:len(dirty_idx)//3], "net_amount"] = np.nan
orders_df.loc[dirty_idx[len(dirty_idx)//3: 2*len(dirty_idx)//3], "quantity"] = -1
orders_df = pd.concat([orders_df, orders_df.sample(50, random_state=2)], ignore_index=True)  # duplicates

# Save
orders_df.to_csv("data/orders.csv", index=False)
customers_df.to_csv("data/customers.csv", index=False)
products_df.to_csv("data/products.csv", index=False)
returns_df.to_csv("data/returns.csv", index=False)

print("Orders:", orders_df.shape)
print("Customers:", customers_df.shape)
print("Products:", products_df.shape)
print("Returns:", returns_df.shape)
