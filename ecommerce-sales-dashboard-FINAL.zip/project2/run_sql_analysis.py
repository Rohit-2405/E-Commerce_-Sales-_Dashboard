import sqlite3
import pandas as pd

conn = sqlite3.connect("data/ecommerce.db")

orders = pd.read_csv("data/orders.csv")
customers = pd.read_csv("data/customers.csv")
products = pd.read_csv("data/products.csv")
returns = pd.read_csv("data/returns.csv")

# ---- CLEANING (mirrors the Pandas EDA step) ----
orders = orders.drop_duplicates(subset=["order_id"])
orders["net_amount"] = orders["net_amount"].fillna(orders["gross_amount"])
orders = orders[orders["quantity"] > 0]

orders.to_sql("orders", conn, if_exists="replace", index=False)
customers.to_sql("customers", conn, if_exists="replace", index=False)
products.to_sql("products", conn, if_exists="replace", index=False)
returns.to_sql("returns", conn, if_exists="replace", index=False)

import re

with open("sql/kpi_queries.sql") as f:
    script = f.read()

# strip /* ... */ comments, then split into individual queries on ';'
script_no_comments = re.sub(r"/\*.*?\*/", "", script, flags=re.DOTALL)
queries = [q.strip() for q in script_no_comments.split(";") if q.strip()]

titles = [
    "1_revenue_by_category", "2_monthly_revenue_growth", "3_q4_vs_rest_spike",
    "4_top10_products", "5_segment_revenue", "6_return_rate_by_category",
    "7_top_return_reasons", "8_region_performance", "9_churn_rate", "10_payment_method_share"
]

results = {}
for title, q in zip(titles, queries):
    df = pd.read_sql_query(q, conn)
    results[title] = df
    df.to_csv(f"data/kpi_{title}.csv", index=False)
    print(f"\n=== {title} ===")
    print(df.to_string(index=False))

conn.close()
